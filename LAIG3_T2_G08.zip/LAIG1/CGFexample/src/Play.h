class Play {
public:
	int pawn,xi,yi,xf,yf;
	Play(int p,int xi,int yi,int xf,int yf){
		pawn=p;
		this->xi=xi;
		this->xf=xf;
		this->yi=yi;
		this->yf=yf;
	}
};
